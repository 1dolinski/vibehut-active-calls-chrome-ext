function updateBadge() {
  fetch('https://vibehut.io/api/v1/public/calls/active-calls', {
    headers: {
      'api-key': '55221ae45adfd8eee24bf704e3f05c1d'
    }
  })
  .then(res => res.json())
  .then(data => {
    const count = data?.data?.length || 0;
    chrome.action.setBadgeText({ 
      text: count > 0 ? count.toString() : '' 
    });
    chrome.action.setBadgeBackgroundColor({ color: 'rgb(113, 109, 255)' });
  })
  .catch(error => {
    console.error('Badge update failed:', error);
    chrome.action.setBadgeText({ text: '' });
    chrome.action.setBadgeBackgroundColor({ color: '#888' });
  });
}

// Create alarm to update badge every 20 seconds (0.33 minutes)
chrome.alarms.create('updateBadge', { 
  periodInMinutes: 0.33 
});

// Listen for alarm
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'updateBadge') {
    updateBadge();
  }
});

// Initial update when extension loads
updateBadge(); 